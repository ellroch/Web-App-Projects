﻿using System.Web.UI;

namespace Ch20UserMaintenance.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}