/*
   New Perspectives on HTML5, CSS, and JavaScript
   Tutorial 13
   Case Problem 2

   Author:   
   Date:     

   Filename: translate.js


   Function List:


   setup()
      Insert the current week's french phrases into document and set up
      event handlers for the phrases.

   showEnglish()
      Changes all of the English phrases to French

   showFrench()
      Changes all of the French phrases to English

*/


